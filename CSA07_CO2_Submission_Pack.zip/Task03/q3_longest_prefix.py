"""Q3: Longest-prefix match demonstration."""
import ipaddress
routes = [
    ("10.0.0.0/8", "192.0.2.1"),
    ("10.1.0.0/16", "192.0.2.5"),
    ("10.1.2.0/24", "192.0.2.9"),
    ("10.1.2.128/25", "192.0.2.13"),
    ("0.0.0.0/0", "198.51.100.1"),
]
for destination in ["10.1.2.200","10.1.2.100","10.1.9.9","10.7.7.7","8.8.8.8"]:
    ip = ipaddress.ip_address(destination)
    matches = [(ipaddress.ip_network(prefix), hop) for prefix,hop in routes
               if ip in ipaddress.ip_network(prefix)]
    network, hop = max(matches, key=lambda item:item[0].prefixlen)
    print(f"{destination:15} -> {hop:15} (matched {network})")
