"""Q1: IPv4 subnet validation and NAT/PAT illustration."""
import ipaddress

devices = [
    ("Admission PC", "172.16.45.200/20", "172.16.32.1"),
    ("Lab printer", "10.0.15.255/21", "10.0.8.1"),
    ("X-ray server", "192.168.4.0/23", "192.168.4.1"),
    ("Clinic router", "203.0.113.10/29", None),
]
for name, address, gateway in devices:
    iface = ipaddress.ip_interface(address)
    net = iface.network
    valid = iface.ip in net.hosts()
    gw_ok = (gateway is None or ipaddress.ip_address(gateway) in net)
    print(f"{name}: network={net.network_address}, broadcast={net.broadcast_address}, "
          f"hosts={net[1]}-{net[-2]}, configured={iface.ip}, valid_host={valid}, gateway_in_subnet={gw_ok}")

print("\\nExample PAT translations (same inside source port 50000):")
print("PC-A 192.168.1.10:50000 -> 203.0.113.10:40001")
print("PC-B 192.168.1.11:50000 -> 203.0.113.10:40002")
