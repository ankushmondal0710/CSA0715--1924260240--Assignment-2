"""Q2: VLSM allocation for 192.168.10.0/24."""
import ipaddress
import math

def vlsm(base, needs):
    addr = int(ipaddress.ip_address(base))
    end = int(ipaddress.ip_network(base + "/24", strict=False).broadcast_address)
    for name, hosts in sorted(needs, key=lambda item: -item[1]):
        block = 1 << math.ceil(math.log2(hosts + 2))
        prefix = 32 - int(math.log2(block))
        addr = (addr + block - 1) // block * block  # align to block boundary
        net = ipaddress.ip_network((addr, prefix))
        if int(net.broadcast_address) > end:
            raise ValueError(f"{name} does not fit in the supplied /24")
        print(f"{name:10} {net} hosts {net.network_address+1} - {net.broadcast_address-1} "
              f"bcast {net.broadcast_address}")
        addr = int(net.broadcast_address) + 1
    print("next free address:", ipaddress.ip_address(addr))

needs = [("Labs",100),("Staff",50),("Library",25),("WAN link",2)]
vlsm("192.168.10.0", needs)

print("\\nHostel check: 60 hosts require /26 (64 addresses); remaining tail is only 28 addresses.")
print("A /23 allocation (192.168.10.0/23) permits hostel 192.168.11.0/26 without renumbering existing subnets.")
