"""Q5: OSPF cost calculations and Dijkstra shortest path example."""
import heapq
reference_mbps=100_000  # 100 Gbps reference bandwidth
speeds_mbps=[10,100,1000,10000]
print("OSPF costs with 100 Mbps default reference:")
for speed in speeds_mbps:
    print(f"{speed:>5} Mbps: cost {max(1,100//speed)}")
print("\\nOSPF costs with 100,000 Mbps reference:")
for speed in speeds_mbps:
    print(f"{speed:>5} Mbps: cost {max(1,reference_mbps//speed)}")

# Six-router example; edge weights are OSPF costs with the new reference.
graph={
 "R1":{"R2":10,"R3":100},
 "R2":{"R1":10,"R4":10,"R5":30},
 "R3":{"R1":100,"R4":100,"R5":20},
 "R4":{"R2":10,"R3":100,"R6":10},
 "R5":{"R2":30,"R3":20,"R6":10},
 "R6":{"R4":10,"R5":10},
}
dist={n:float("inf") for n in graph}; prev={}
dist["R1"]=0; pq=[(0,"R1")]
while pq:
    d,u=heapq.heappop(pq)
    if d!=dist[u]: continue
    for v,w in graph[u].items():
        nd=d+w
        if nd<dist[v]:
            dist[v]=nd; prev[v]=u; heapq.heappush(pq,(nd,v))
for n in graph:
    path=[n]; cur=n
    while cur in prev:
        cur=prev[cur]; path.append(cur)
    print(f"R1 to {n}: cost {dist[n]}, path {'-'.join(reversed(path))}")
